import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { authGuard } from './core/guards/auth.guard';
import { CreateTicketComponent } from './features/department/create-ticket/create-ticket.component';
import { DepartmentLayoutComponent } from './features/department/department-layout/department-layout.component';
import { TicketListComponent } from './features/department/ticket-list/ticket-list.component';
import { DepartmentHomeComponent } from './features/department/home/home.component';
import { DitPendingComponent } from './features/dit/dit-pending/dit-pending.component';
import { DitHomeComponent } from './features/dit/dit-home/dit-home.component';
import { DitLayoutComponent } from './features/dit/dit-layout/dit-layout.component';
import { SdcPendingComponent } from './features/sdc/sdc-pending/sdc-pending.component';
import { SdcHomeComponent } from './features/sdc/sdc-home/sdc-home.component';
import { SdcLayoutComponent } from './features/sdc/sdc-layout/sdc-layout.component';
import { SdcActiveComponent } from './features/sdc/sdc-active/sdc-active.component';
import { TicketDetailsComponent } from './features/shared/ticket-details/ticket-details.component';
import { DitHistoryComponent } from './features/dit/dit-history/dit-history.component';
import { SdcHistoryComponent } from './features/sdc/sdc-history/sdc-history.component';


export const routes: Routes = [
  // 1. Default Route -> Login
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // 2. The Login Page
  { path: 'login', component: LoginComponent },

  // 3. The Register Page
  { path: 'register', component: RegisterComponent },

  // 3. Protected Department Routes
  { 
    path: 'department', 
    component: DepartmentLayoutComponent,
    children: [
      { path: 'home', component: DepartmentHomeComponent },         
      { path: 'my-tickets', component: TicketListComponent },        
      { path: 'create-ticket', component: CreateTicketComponent },  
      { path: 'ticket/:id', component: TicketDetailsComponent },
      { path: '', redirectTo: 'home', pathMatch: 'full' }
    ]
    , canActivate: [authGuard]
  },
  { 
    path: 'dit', 
    component: DitLayoutComponent,
    children: [
      { path: 'home', component: DitHomeComponent },
      { path: 'pending', component: DitPendingComponent },
      { path: 'ticket/:id', component: TicketDetailsComponent },
      { path: 'history', component: DitHistoryComponent },
      { path: '', redirectTo: 'home', pathMatch: 'full' }
    ]
    , canActivate: [authGuard]
  },

  { 
    path: 'sdc', 
    component: SdcLayoutComponent,
    children: [
      { path: 'home', component: SdcHomeComponent },
      { path: 'pending', component: SdcPendingComponent }, 
      { path: 'active', component: SdcActiveComponent },
      { path: 'ticket/:id', component: TicketDetailsComponent },
      { path: 'history', component: SdcHistoryComponent },
      { path: '', redirectTo: 'home', pathMatch: 'full' }
    ]
    , canActivate: [authGuard]
  },

  // 4. Fallback (404)
  { path: '**', redirectTo: 'login' }
];