import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterService, RegisterRequest } from './register.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  isLoading = false;
  errorMessage = '';
  roles = [
    { display: 'Department User', value: 'DEPARTMENT' },
    { display: 'Project Manager', value: 'DIT' },
    { display: 'SDC Staff', value: 'SDC' }
  ];
  departments = ['IT Dept', 'Cisco Dept']; // Matching backend DEPARTMENT_CHOICES

  constructor(
    private fb: FormBuilder,
    private registerService: RegisterService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]],
      phone_number: ['', Validators.required],
      role: ['', Validators.required],
      department: ['']
    }, { validators: this.passwordMatchValidator });

    // Dynamically set department validator based on role
    this.registerForm.get('role')?.valueChanges.subscribe(value => {
      const departmentControl = this.registerForm.get('department');
      if (value === 'DEPARTMENT') {
        departmentControl?.setValidators([Validators.required]);
      } else {
        departmentControl?.clearValidators();
      }
      departmentControl?.updateValueAndValidity();
    });
  }

  passwordMatchValidator(control: AbstractControl): { [key: string]: any } | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      return { 'passwordMismatch': true };
    }
    return null;
  }

  get showDepartment(): boolean {
    return this.registerForm.get('role')?.value === 'DEPARTMENT';
  }

  onSubmit() {
    if (this.registerForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';

      const formValue = this.registerForm.value;
      const request: RegisterRequest = {
        username: formValue.username,
        email: formValue.email,
        password: formValue.password,
        confirm_password: formValue.confirmPassword,
        phone_number: formValue.phone_number,
        role: formValue.role,
        department: formValue.role === 'DEPARTMENT' ? formValue.department : undefined
      };

      this.registerService.register(request).subscribe({
        next: (res) => {
          this.isLoading = false;
          // Assuming success, redirect to login
          this.router.navigate(['/login']);
        },
        error: (err) => {
          this.isLoading = false;
          this.errorMessage = err.message;
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched() {
    Object.keys(this.registerForm.controls).forEach(key => {
      const control = this.registerForm.get(key);
      control?.markAsTouched();
    });
  }
}
